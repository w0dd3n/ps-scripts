# Importer le module Active Directory
Import-Module ActiveDirectory

Write-Host "La création des utilisateurs peut commencer"
read-host "Press ENTER to continue..."

# Stocke les données du .csv dans la variable $ADUsers (Le répertoire du csv est le même que le script)
$ADUsers = Import-Csv $PSScriptRoot"\Users.csv" -Delimiter ";" -Encoding UTF8 #Bien vérifier que le CSV est enregistré au format UTF8, sinon problème avec les lettres accentuées

$UsersPasswd="Apprenant59"
$DC=(Get-ADDomain).DistinguishedName
$UPN = (Get-ADDomain).DNSRoot

# Récupérer le nom complet du serveur
# Le nom NetBIOS ($env:COMPUTERNAME) cause des problèmes dans l'utilisation des profils itinérants
# Le nom complet <serveur>.<domaine> corrige ces problèmes
$ServName = hostname
$ServFQDN = $ServName+"."+$UPN

try{
    # Boucle chaque ligne contenant des infos utilisateurs
    foreach ($User in $ADUsers) {

        # Lis les infos utilisateurs de chaque champ dans chaque ligne et assigne les données à  une variable ci-dessous 
        $utilisateur = $User.SamID
        $password = $UsersPasswd
        $prenom = $User.FirstName
        $nomdefamille = $User.LastName
        $DisplayName = $User.DisplayName
        $Initials = $User.Initials
        $PathOU = "$($User.OU),$DC" #Ce champ se réfère à  l'OU où le compte utilisateur doit être créé
        $poste = $User.JobTitle
        $departement = $User.Department
        if ($User.MustChPwd)
            {
            $MustChPswd = [System.Convert]::ToInt32($User.MustChPswd)
            }
        else
            {
            $MustChPswd=$null
            }
        if ($User.PwdNeverExpires)
            {
            $ExpPswd = [System.Convert]::ToInt32($User.PwdNeverExpires)
            }
        else
            {
            $ExpPswd = $null
            }
        $UserProfile = $User.Profile
        $Group = "$($User.MemberOf),$DC"

        # Vérifie si l'utilisateur existe déjà  dans l'AD
        if (Get-ADUser -F { SamAccountName -eq $utilisateur }) {
        
            # Avertissement si l'utilisateur existe
            Write-Warning "Un utilisateur avec le nom $utilisateur existe déjà dans Active Directory."
        }
        else {

            # Si l'utilisateur n'existe pas alors créé l'utilisateur
            # Le compte sera créé dans l'OU fournie par la variable $OU lu dans le fichier .csv
            New-ADUser `
                -SamAccountName $utilisateur `
                -UserPrincipalName "$utilisateur@$UPN" `
                -Name "$prenom $nomdefamille" `
                -GivenName $prenom `
                -Surname $nomdefamille `
                -Initials $Initials `
                -PasswordNeverExpires $ExpPswd `
                -ChangePasswordAtLogon $MustChPswd `
                -ProfilePath "\\$ServFQDN\Profil$\$UserProfile" `
                -Enabled $True `
                -DisplayName $DisplayName `
                -Path $PathOU `
                -Title $poste `
                -Department $departement `
                -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force)

            if ($User.MemberOf){
                Add-ADGroupMember -Identity $Group -Members $utilisateur
            }

            # Si l'utilisateur est créé, affiche le message suivant
            Write-Host "L'utilisateur $utilisateur a été créé." -ForegroundColor Cyan
        }
    }
}
catch
{
    Write-Host "Erreur : Une erreur est survenue lors de la création des utilisateurs"
    Write-Host "$Error"
    Write-Host $_.ScriptStackTrace
    }

Read-Host -Prompt "Appuyer sur Entrée pour quitter."