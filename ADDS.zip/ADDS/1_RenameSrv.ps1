#____________________________
#
# Renommer le serveur
#____________________________

#Changer le nom du serveur
Rename-Computer -NewName ADDS-OPTI3020-01 -Force -Restart
