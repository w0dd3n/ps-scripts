# Installation automatique d'un serveur ADDS

## Auteurs

Yann Hamonic - <yhamonic.simplon@gmail.com>

Florian Fuentes - <ffuentes.simplon@gmail.com>

Angelo Capogrosso - <acapogrosso.simplon@gmail.com>

## Version

![Windows](https://img.shields.io/badge/Windows%20Server-19-informational)
![PowerShell](https://img.shields.io/badge/PowerShell-5.1-informational)

---

## 1. Prérequis

Les fichiers doivent être dans le même dossier

* RenameSrv.ps1
* Install-ADDS-DNS.ps1
* Config-ADDS.ps1
* CreateUsers.ps1
* Users.csv

>Vérifier que le fichier Users.csv utilise bien le ';' comme séparateur et qu'il est encodé en UTF8

## 2. Procédure

> * Lancer Powershell en tant qu'Administrateur
> * Cliquer-Glisser le script souhaité et appuyer sur **Entrée**

Lancer les scripts dans l'ordre suivant

* **RenameSrv.ps1**
    * Le serveur redémarre automatiquement
* **Install-ADDS-DNS.ps1**
    * Le serveur redémarre automatiquement
* **Config-ADDS.ps1**
    * **CreateUsers.ps1** se lancera automatiquement à la fin de la configuration

## 3. Créer une GPO pour les droits spécifiques au dossier Profil$

Afin que les utilisateurs puissent accéder à leur compte, il est essentiel de créer une GPO spécifique au niveau du domaine.

Dans l'outil "Gestion des stratégies de groupe" :

* Créer et lier une nouvelle GPO dans le domaine
* Dans l'onglet **Etendue** ; Filtrage de sécurité
    * Supprimer l'information "Utilisateurs Authentifiés"
    * Ajouter le groupe "Profils utilisateurs itinérants"
* Dans l'onglet **Délégation**
    * Ajouter le groupe "Utilisateurs Authentifiés" en lecture seule

## 4. Ajout ultérieur d'utilisateurs

Pour de futurs ajouts d'utilisateurs, le script **CreateUsers.ps1** peut être utilisé avec un autre fichier **Users.csv** contenant les nouveaux utilisateurs.

> :warning: Attention à conserver le format original de **Users.csv** notamment les en-têtes