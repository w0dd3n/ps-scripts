# Configuration de la carte réseaux, implémentation de l'adresse IP fixe
New-NetIPAddress -InterfaceIndex (Get-NetIPConfiguration).InterfaceIndex[0] -IPAddress 10.10.20.253 -PrefixLength 27 -DefaultGateway 10.10.20.225
Set-DnsClientServerAddress -InterfaceIndex (Get-NetIPConfiguration).InterfaceIndex[0] -ServerAddresses ("192.168.1.254","192.168.1.1")

# Installation des roles AD DS et DNS
$FeatureList = @("AD-Domain-Services","DNS")

Foreach($Feature in $FeatureList){

   if(((Get-WindowsFeature -Name $Feature).InstallState)-eq"Available"){

     Write-Output "Feature $Feature will be installed now !"

     Try{

        Add-WindowsFeature -Name $Feature -IncludeManagementTools -IncludeAllSubFeature

        Write-Output "$Feature : Installation is a success !"

     }Catch{

        Write-Output "$Feature : Error during installation !"
     }
   }
}

# Paramètre de la forêt
$DomainNameDNS = "cloud-strike.lan"
$DomainNameNetbios = "CLOUD-STRIKE"
$SafeModeClearAdminPassword = "P@ssw0rd!"
$SafeModeAdministratorPassword = ConvertTo-SecureString $SafeModeClearAdminPassword -AsPlaintext -Force:$true

# Configuration de la forêt avec les noms de domaine
$ForestConfiguration = @{
'-DatabasePath'= 'C:\Windows\NTDS';
'-DomainMode' = 'Default';
'-DomainName' = $DomainNameDNS;
'-DomainNetbiosName' = $DomainNameNetbios;
'-ForestMode' = 'Default';
'-InstallDns' = $true;
'-LogPath' = 'C:\Windows\NTDS';
'-NoRebootOnCompletion' = $false;
'-SysvolPath' = 'C:\Windows\SYSVOL';
'-SafeModeAdministratorPassword' = $SafeModeAdministratorPassword;
'-Force' = $true;
'-CreateDnsDelegation' = $false
}

Import-Module ADDSDeployment
Install-ADDSForest @ForestConfiguration