<####################################################
# Ce script permet la création au sein d'un domaine
# des OU, des Groupes, des répertoires partagés et
# des droits d'accès liés (ACL).
# Un script externe permet de créer les utilisateurs
#____________________________________________________#>

Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt

#Vérifier l'existence des services essentiels
$mess = "`nVérifier le statut des services essentiels"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

$services = Get-Service -Name ADWS, KDC, NetLogon, DNS 
foreach ($service in $services) { 
  if ($service.Status -ne 'Running') {
    $mess = "Le service $($service.Name) n'est pas en cours d'exécution."
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
    $mess = "Le paramétrage d'ADDS ne peut pas commencer"
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
    throw $mess
  }
}
$mess = "Le paramétrage d'ADDS peut commencer"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
read-host "Press ENTER to continue..."


# Import des cmdlets AD
$mess = "`nImport des cmdlets AD"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try {
    Import-Module ActiveDirectory -ErrorAction Stop
} catch {
    $mess = "`nErreur : $_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}

# Variables : à modifier si besoin

#Récupere automatiquement le nom du domaine
$DomFQDN=(Get-ADDomain).DNSRoot
#Remplace DC=$Domaine,DC=$DomTLD
$DC=(Get-ADDomain).DistinguishedName

$DossierPartage1="D:\Commun"
$NomPartage1="Commun"
$GroupL1="GP_"+$NomPartage1+"_Lecture"
$GroupE1="GP_"+$NomPartage1+"_Ecriture"

$DossierPartage2="D:\Administration"
$NomPartage2="Administration"
$GroupL2="GP_"+$NomPartage2+"_Lecture"
$GroupE2="GP_"+$NomPartage2+"_Ecriture"

$DossierPartage3="D:\Vente"
$NomPartage3="Vente"
$GroupL3="GP_"+$NomPartage3+"_Lecture"
$GroupE3="GP_"+$NomPartage3+"_Ecriture"

$DossierPartage4="D:\Technique"
$NomPartage4="Technique"
$GroupL4="GP_"+$NomPartage4+"_Lecture"
$GroupE4="GP_"+$NomPartage4+"_Ecriture"

#Créer le dossier spécifique aux profils itinérants
$DossierProfil="D:\Profil$"
$NomPartageProfil="Profil$"
#Groupe ayant les droits sur l'utilisation des profils
$GroupProfil="Profils Utilisateurs Itinérants"


# Vérification de l'existence du dossier SYSVOL à l'emplacement indiqué dans le premier script (Install-ADDS-DNS) - retourne la valeur "true" si OK
Test-Path "C:\Windows\SYSVOL"

# Création des Unités d'Organisation (OU)
$mess = "`nCréation des Unités d'Organisation (OU)"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try {
    ## OU Informatique
    New-ADOrganizationalUnit -Name "Informatique" -Path "$DC"
    New-ADOrganizationalUnit -Name "Groupe" -Path "OU=Informatique,$DC"
    ## OU Direction
    New-ADOrganizationalUnit -Name "Direction" -Path "$DC"
    ## OU Administratif
    New-ADOrganizationalUnit -Name "Administratif" -Path "$DC"
    New-ADOrganizationalUnit -Name "Comptable" -Path "OU=Administratif,$DC"
    New-ADOrganizationalUnit -Name "Secretariat" -Path "OU=Administratif,$DC"
    New-ADOrganizationalUnit -Name "Standard" -Path "OU=Administratif,$DC"
    ## OU Vente
    New-ADOrganizationalUnit -Name "Vente" -Path "$DC"
    New-ADOrganizationalUnit -Name "Boutique" -Path "OU=Vente,$DC"
    New-ADOrganizationalUnit -Name "Stock" -Path "OU=Vente,$DC"
    New-ADOrganizationalUnit -Name "Commercial" -Path "OU=Vente,$DC"
    ## OU Technique
    New-ADOrganizationalUnit -Name "Technique" -Path "$DC"
    New-ADOrganizationalUnit -Name "Developpement" -Path "OU=Technique,$DC"
    New-ADOrganizationalUnit -Name "Formation" -Path "OU=Technique,$DC"
    New-ADOrganizationalUnit -Name "Fabrication" -Path "OU=Technique,$DC"
} catch{
    $mess = "Erreur : Une erreur est survenue lors de la création des OU`n$_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to continue..."
clear

# Création des répertoires partagés en D:
$mess = "`nCréation des répertoires partagés en D:"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try{
    New-Item -ItemType "directory" -Path $DossierPartage1
    New-Item -ItemType "directory" -Path $DossierPartage2
    New-Item -ItemType "directory" -Path $DossierPartage3
    New-Item -ItemType "directory" -Path $DossierPartage4
    New-Item -ItemType "directory" -Path $DossierProfil
    New-Item -ItemType "directory" -Path D:\Profil\Administratif\Secretariat
    New-Item -ItemType "directory" -Path D:\Profil\Administratif\Standard\
    New-Item -ItemType "directory" -Path D:\Profil\Technique\Developpement
    New-Item -ItemType "directory" -Path D:\Profil\Technique\Formation\
    New-Item -ItemType "directory" -Path D:\Profil\Vente\Boutique
    New-Item -ItemType "directory" -Path D:\Profil\Vente\Commercial
    New-Item -ItemType "directory" -Path D:\Profil\Direction
} catch{
    $mess = "Erreur : Une erreur est survenue lors de la création des répertoires`n$_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

Read-Host "Press ENTER to continue..."
clear

# Paramétrage des répertoires partagés
$mess = "`nParamétrage des répertoires partagés"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
try{
    New-SmbShare -Name $NomPartage1 -Path $DossierPartage1 -FullAccess "Tout le monde"
    New-SmbShare -Name $NomPartage2 -Path $DossierPartage2 -FullAccess "Tout le monde"
    New-SmbShare -Name $NomPartage3 -Path $DossierPartage3 -FullAccess "Tout le monde"
    New-SmbShare -Name $NomPartage4 -Path $DossierPartage4 -FullAccess "Tout le monde"
    New-SmbShare -Name $NomPartageProfil -Path $DossierProfil -FullAccess "BUILTIN\Administrateurs"
} catch{
    $mess = "Erreur : Une erreur est survenue lors du partage des répertoires`n$_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to continue..."
clear

# Création des groupes de sécurité des répertoires partagés
$mess = "`nCréation des groupes de sécurité des répertoires partagés"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try{
    New-ADGroup -Name $GroupL1 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupL2 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupL3 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupL4 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"

    New-ADGroup -Name $GroupE1 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupE2 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupE3 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name $GroupE4 -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
} catch{
    $mess = "Erreur : Une erreur est survenue lors de la création des groupes de sécurité`n$_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to continue..."
clear

# Création des groupes de services
$mess = "`nCréation des groupes de services"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try{
    New-ADGroup -Name "Comptables" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Secretaires" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Standardistes" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Developpeurs" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Formateurs" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Fabricants" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Vendeurs" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Commerciaux" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Magasiniers" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Directeurs" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    New-ADGroup -Name "Informatique" -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    #Groupe pour profils itinérants
    New-ADGroup -Name $GroupProfil -GroupCategory Security -GroupScope Global -Path "OU=Groupe,OU=Informatique,$DC"
    Add-ADGroupMember -Identity $GroupProfil -Members Comptables,Secretaires,Standardistes,Developpeurs,Formateurs,Fabricants,Vendeurs,Commerciaux,Magasiniers,Directeurs
    
    Add-ADGroupMember -Identity $GroupL1 -Members Comptables,Secretaires,Standardistes,Developpeurs,Formateurs,Fabricants,Vendeurs,Commerciaux,Magasiniers,Directeurs
    Add-ADGroupMember -Identity $GroupE1 -Members Informatique
    
    Add-ADGroupMember -Identity $GroupL2 -Members Standardistes,Directeurs
    Add-ADGroupMember -Identity $GroupE2 -Members Comptables,Secretaires

    Add-ADGroupMember -Identity $GroupL3 -Members Directeurs
    Add-ADGroupMember -Identity $GroupE3 -Members Vendeurs,Commerciaux,Magasiniers

    Add-ADGroupMember -Identity $GroupL4 -Members Directeurs
    Add-ADGroupMember -Identity $GroupE4 -Members Developpeurs,Fabricants
} catch{
    $mess = "Erreur : Une erreur est survenue lors de la création des groupes de service `n$_"
    Write-Host $mess
    Write-Host $_.ScriptStackTrace
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
    $_.ScriptStackTrace | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to continue..."
clear


# Paramétrage des droits sur les dossiers partagés
$mess = "`nParamétrage des droits sur les dossiers partagés"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try{
    $Dossiers= @($DossierPartage1,$DossierPartage2,$DossierPartage3,$DossierPartage4)
    $GroupsL = @("$DomFQDN\$GroupL1","$DomFQDN\$GroupL2","$DomFQDN\$GroupL3","$DomFQDN\$GroupL4")
    $GroupsE = @("$DomFQDN\$GroupE1","$DomFQDN\$GroupE2","$DomFQDN\$GroupE3","$DomFQDN\$GroupE4")
    $isProtected=$true
    $preserveInheritance=$false

    for ($i=0; $i -lt $Dossiers.Length; $i++) {
        $Acl = Get-Acl -Path $Dossiers[$i]
        $Rule1 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule($GroupsL[$i],"ReadAndExecute","Allow")
        $Rule2 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule($GroupsE[$i],"Modify","Allow")
        $Rule3 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule("Builtin\Administrateurs","FullControl","Allow")
        $Acl.AddAccessRule($Rule1)
        $Acl.AddAccessRule($Rule2)
        $Acl.AddAccessRule($Rule3)
        $Acl.SetAccessRuleProtection($isProtected, $preserveInheritance)
        $Acl | Set-Acl
    }
    #Règles spécifiques au dossier Profil$
    $AclProfil = Get-Acl -Path $DossierProfil
    $Rule1 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule("$DomFQDN\$GroupProfil","ReadData,AppendData,Synchronize","Allow")
    $Rule2 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule("Builtin\Administrateurs","FullControl","Allow")
    $Rule3 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule("Autorité NT\Système","FullControl","Allow")
    $Rule4 = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule("Créateur Propriétaire","FullControl","Allow")
    $AclProfil.AddAccessRule($Rule1)
    $AclProfil.AddAccessRule($Rule2)
    $AclProfil.AddAccessRule($Rule3)
    $AclProfil.AddAccessRule($Rule4)
    $AclProfil.SetAccessRuleProtection($isProtected, $preserveInheritance)
    $AclProfil | Set-Acl
} catch {
    $mess = "Erreur : Une erreur est survenue lors de la création des groupes de service `n$_"
    Write-Host $mess
    Write-Host $_.ScriptStackTrace
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
    $_.ScriptStackTrace | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Opération terminée avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to continue..."
clear

# Création des utilisateurs
$mess = "`nChargement du script de création des utilisateurs"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

try{
    $addUsers = $PSScriptRoot+"\CreateUsers.ps1"
    & $addUsers
} catch{
    $mess = "Erreur : Une erreur est survenue lors du chargement du script CreateUsers.ps1`n$_"
    Write-Host $mess
    $mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append
}
$mess = "Le script s'est déroulé avec succès"
Write-Host $mess
$mess | Out-File -FilePath $PSScriptRoot\Rapport_Config-ADDS.txt -Append

read-host "Press ENTER to finish !!"

